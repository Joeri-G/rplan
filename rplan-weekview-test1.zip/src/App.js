import React, {Component} from 'react';
import './App.css';
import Calendar from "./calendar/Calendar";

class App extends Component {
  render() {
    return (
        <Calendar/>
    );
  }
}

export default App;
